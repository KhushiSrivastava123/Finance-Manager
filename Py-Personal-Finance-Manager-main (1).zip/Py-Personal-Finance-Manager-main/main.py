
import sys
from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QStackedLayout, QMainWindow, QToolBar
from screens import TransactionScreen, AddScreen, StatsScreen, BudgetsScreen, BillsScreen, AddBudgetScreen, AddBills



class MainWindow(QMainWindow):
    """This class provides the methods to create Main UI .

    Args:
        QMainWindow (class): This class provides a main application window
    """

    def __init__(self, account_id):
        super().__init__()
        self.account_id = account_id
        self.setWindowTitle('Finance Manager')
        self.stacked_layout_class_map = {
            'Home': TransactionScreen,
            'Status': StatsScreen,
            'Budgets': BudgetsScreen,
            'Bills': BillsScreen,
            'Add': AddScreen,
            'AddBudgets': AddBudgetScreen,
            'AddBills': AddBills
        }
        self.stacked_layout_index = {
            'Home': 0,
            'Status': 1,
            'Budgets': 2,
            'Bills': 3
        }
        self.toolbar = QToolBar("Example")
        self.addToolBar(QtCore.Qt.BottomToolBarArea, self.toolbar)
        for key in self.stacked_layout_index.keys():
            self.toolbar.addAction(key).triggered.connect(self.on_click_method)
        self.toolbar.layout().setSpacing(50)

        self.initUI()

    def initUI(self):
        """This function creates stacked screeens for Main UI.
        """

        self.stackedLayout = QStackedLayout()
        for cls in self.stacked_layout_class_map.values():
            self.stackedLayout.addWidget(cls(self.account_id))

        self.main_layout = QVBoxLayout()
        self.main_layout.addLayout(self.stackedLayout)

        central_widget = QWidget(self)
        central_widget.setLayout(self.main_layout)
        self.setCentralWidget(central_widget)
        self.show()

    def on_click_method(self):
        """This function helps to navigate from one screen to other screen.
        """
        button_name = self.sender().text()
        self.stackedLayout.setCurrentIndex(self.stacked_layout_index[button_name])
    
    
if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = MainWindow(1)
    w.resize(900, 600)
    # w.show()
    sys.exit(app.exec_())