import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QDialog,  QMessageBox

from model import Account
from main import MainWindow

class LoginUI(QWidget):
    """This class provides the methods to create Login UI .

    Args:
        QWidget (class): Base class for all user interface elements.
        
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle('Login')
        self.setGeometry(200, 200, 300, 150)
        self.login = Account()
        self.setup_ui()

    def setup_ui(self):
        """This function creates Login UI.
        """

        layout = QVBoxLayout()
        self.label_email = QLabel('Email Address:')
        self.lineedit_email = QLineEdit()

        self.label_password = QLabel('Password:')
        self.lineedit_password = QLineEdit()
        self.lineedit_password.setEchoMode(QLineEdit.Password)
        self.button_login = QPushButton('Login')
        self.create_account_button = QPushButton("Create Account", self)
        self.button_login.clicked.connect(self.login_clicked)
        self.create_account_button.clicked.connect(self.show_create_account_dialog)


        layout.addWidget(self.label_email)
        layout.addWidget(self.lineedit_email)
        layout.addWidget(self.label_password)
        layout.addWidget(self.lineedit_password)
        layout.addWidget(self.button_login)
        layout.addWidget(self.create_account_button)

        self.setLayout(layout)

    def login_clicked(self):
        """This method retrieves information from the Login UI and validates user credentials.
        """
        email = self.lineedit_email.text()
        password = self.lineedit_password.text()
        auth = self.login.check_authentication(email, password)

        if auth:
            # todo: create and call the funtion to get the account_id of the
            #  user and replace the hard code value below.
            account_id = 1
            QMessageBox.information(self, "Login Successfull", "Login Successfull")
            self.new_window = MainWindow(account_id)
            self.new_window.resize(900, 600)
            self.new_window.show()
            self.close()

        else:
            QMessageBox.warning(self, "Invalid Credendtials",
                                "Please provide valid username or password")

    def show_create_account_dialog(self):
        """This function shows Dialog box to create account"""
        create_account_dialog = CreateAccountDialog(self)
        if create_account_dialog.exec_() == QDialog.Accepted:
            print("Account created successfully.")

class CreateAccountDialog(QDialog):
    """This class provides the methods to Create account UI"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create Account")
        self.setGeometry(100, 100, 300, 150)
        self.login = Account()

        layout = QVBoxLayout()

        self.username_label = QLabel("Username:", self)
        layout.addWidget(self.username_label)

        self.username_input = QLineEdit(self)
        layout.addWidget(self.username_input)

        self.password_label = QLabel("Password:", self)
        layout.addWidget(self.password_label)

        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)

        self.create_account_button = QPushButton("Create Account", self)
        self.create_account_button.clicked.connect(self.create_account)
        layout.addWidget(self.create_account_button)

        self.setLayout(layout)

    def create_account(self):
        """This method gets the email and password information from create account UI and inserts data into database.
        """
        email = self.username_input.text()
        password = self.password_input.text()
        hash_pswd = self.login.encrypt_passwd(password)
        email_exists = self.login.check_email(email)
        long_passwd = self.login.check_password(password)
        if email_exists:
            QMessageBox.warning(self, "Email Exists",
                                "This email already exists")

        if not long_passwd:
            QMessageBox.warning(self, "Password Strength",
                                "Please provide stronger password")

        else:
            add_cred = self.login.add_credentials(email, hash_pswd)
            QMessageBox.information(self, "Account Created Successfully", "You have successfully created the account")
            self.accept()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    login_window = LoginUI()
    login_window.show()
    sys.exit(app.exec_())
