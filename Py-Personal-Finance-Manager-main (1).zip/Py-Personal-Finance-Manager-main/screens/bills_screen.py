from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, \
    QTableWidgetItem, QPushButton, QHBoxLayout, QGridLayout, QDateEdit
from PyQt5.QtCore import QDate, Qt

from model import Bills
from PyQt5.QtGui import QColor

from screens.transaction_screen import update_transactions
from screens.budgets_screen import update_budgets

def update_bills(obj):
    """This function updates the Bill screen's table data.
    """
    obj.parent().parent().findChild(BillsScreen).update_table()


class BillsScreen(QWidget):
    """This class provides the methods to create, modify, update the Budget UI.

    Args:
        QWidget (class): Base class for all user interface elements.
    """

    def __init__(self, account_id):
        super().__init__()
        self.current_date = QDate.currentDate()
        self.bills = Bills(account_id)


        self.init_ui()

    def init_ui(self):
        """This function creates the UI for Budgets
        """
        label = QLabel('Budgets')
        layout1 = QHBoxLayout()

        # UI DATE Row
        # QDateEdit for displaying the current date
        self.date_edit = QDateEdit()
        self.date_edit.setDisplayFormat("MMMM, yyyy")
        self.date_edit.setDate(self.current_date)
        self.date_edit.setReadOnly(True)

        # QPushButton for "Previous" and "Next" functionality
        self.previous_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.previous_button.clicked.connect(self.show_previous_date)
        self.next_button.clicked.connect(self.show_next_date)
        layout1.addWidget(self.previous_button)
        layout1.addWidget(self.date_edit)
        layout1.addWidget(self.next_button)


        # ---------UI Table-------------
        self.table_widget = QTableWidget()
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(4)
        self.table_widget.setHorizontalHeaderLabels(
            ["Bill ID", "Bill Name", "Amount", "Pay"])
        self.update_table()

        # ---------UI add and delete button -------------
        self.add_button_layout = QGridLayout()
        self.addButton = QPushButton("Add", self)
        self.deleteButton = QPushButton("Delete", self)
        self.add_button_layout.addWidget(self.addButton, 0, 0)
        self.add_button_layout.addWidget(self.deleteButton, 0, 1)
        self.addButton.clicked.connect(self.add_bill)
        self.deleteButton.clicked.connect(self.delete_selected_bill)




        layout = QVBoxLayout()
        layout.addWidget(label)
        layout.addLayout(layout1)
        layout.addWidget(self.table_widget)
        layout.addLayout(self.add_button_layout)

        self.setLayout(layout)

    def show_previous_date(self):
        """This function sets the date based on previous button navigation
        """
        self.current_date = self.current_date.addMonths(-1)
        self.date_edit.setDate(self.current_date)
        update_bills(self)



    def show_next_date(self):
        """This function sets the date based on next button navigation
        """
        self.current_date = self.current_date.addMonths(1)
        self.date_edit.setDate(self.current_date)
        update_bills(self)


    def update_table(self):
        """This function updates the bills table in Bills UI.
        """
        month = self.date_edit.text()
        data = self.bills.get(month)
        self.table_widget.clearContents()
        self.table_widget.setRowCount(len(data))
        for row, (bill_id, bill_name, ammount, status ) in enumerate(data):
            item_id = QTableWidgetItem(str(bill_id))
            item_name = QTableWidgetItem(bill_name)
            item_amount = QTableWidgetItem(str(ammount))
            item_status = QTableWidgetItem(str(status))
            button_text = 'Paid' if status else 'Pay'
            pay_button = QPushButton(button_text)
            pay_button.clicked.connect(self.pay_bill)
            self.table_widget.setCellWidget(row, 3, pay_button)

            item_id.setFlags(item_id.flags() & ~Qt.ItemIsEditable)
            item_name.setFlags(item_name.flags() & ~Qt.ItemIsEditable)
            if not status:
                pay_button.setStyleSheet('background-color: green; color: white;')
            else:
                item_amount.setFlags(item_amount.flags() & ~Qt.ItemIsEditable)
                pay_button.setEnabled(False)
            item_status.setFlags(item_status.flags() & ~Qt.ItemIsEditable)
            self.table_widget.setItem(row, 0, item_id)
            self.table_widget.setItem(row, 1, item_name)
            self.table_widget.setItem(row, 2, item_amount)

            # Adding colorful background for better visibility
            if row % 2 == 0:
                # Light Blue
                item_id.setBackground(QColor(191, 235, 255))
                item_name.setBackground(QColor(191, 235, 255))
                item_amount.setBackground(QColor(191, 235, 255))
                item_status.setBackground(QColor(191, 235, 255))

            else:
                # Powder Blue
                item_id.setBackground(QColor(191, 235, 255))
                item_name.setBackground(QColor(176, 224, 230))
                item_amount.setBackground(QColor(176, 224, 230))
                item_status.setBackground(QColor(176, 224, 230))


    def pay_bill(self):
        row = self.table_widget.currentRow()
        bill_id = self.table_widget.item(row, 0).text()
        bill_name = self.table_widget.item(row, 1).text()
        amount = self.table_widget.item(row, 2).text()
        month = self.date_edit.text()
        self.bills.pay(bill_id, bill_name, amount, month)
        update_transactions(self)
        update_bills(self)
        update_budgets(self)


    def delete_selected_bill(self):
        """This function deletes the record from bills table in budget UI.
        """
        selected_rows = set(
            index.row() for index in self.table_widget.selectedIndexes())
        if not selected_rows:
            return
        for row in selected_rows:
            bill_id = self.table_widget.item(row, 0).text()
            self.bills.delete(bill_id)
            self.update_table()

    def add_bill(self):
        "This function changes the screen to add bill screen"
        self.parent().parent().stackedLayout.setCurrentIndex(6)

