from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel,  QLineEdit, \
    QPushButton, QMessageBox, QComboBox
from screens.budgets_screen import BudgetsScreen
from model import Category
from model import Budget
import time
import datetime
from PyQt5.QtGui import QIntValidator
from PyQt5.QtCore import  Qt


class AddBudgetScreen(QWidget):
    """This class provides the methods to create UI for adding Budgets.

    Args:
        QWidget (class): Base class for all user interface elements.
    """

    def __init__(self, account_id):
        super().__init__()
        self.account_id = account_id
        self.category = Category()
        self.budget = Budget(account_id)
        self.init_ui()

    def init_ui(self):
        """This function creates the UI for adding budgets.
        """
        self.window_title = QLabel('Add Budgets')
        self.category_label = QLabel("Category:")
        self.category_combo = QComboBox()
        self.category_combo.addItem("Select the category", userData=0)
        categories = self.category.get_budget_category()
        for cat in categories:
            self.category_combo.addItem(cat[0], userData=cat[0])
        self.amount_entry = QLineEdit()
        self.amount_entry.setValidator(QIntValidator())
        self.save_button = QPushButton('Save')
        self.save_button.clicked.connect(self.save_budget)
        title = self.setWindowTitle('Set Budgets')
        layout = QVBoxLayout()
        layout.addWidget(self.window_title)
        layout.addWidget(self.category_label)
        layout.addWidget(self.category_combo)
        layout.addWidget(QLabel('Amount:'))
        layout.addWidget(self.amount_entry)
        layout.addWidget(self.save_button)
        layout.setAlignment(Qt.AlignTop)
        self.setLayout(layout)

    def save_budget(self):
        """This function gets the data from add budget screen UI and saves the data in database. 
           It also updates data in budgets UI.
        """
        category_id = self.category_combo.currentIndex()
        amount = self.amount_entry.text()
        current_date = datetime.date.today()
        if not category_id or not amount:
            QMessageBox.critical(self, 'Error', 'Please enter all fields.')
            return
        try:
            amount = float(amount)
        except ValueError:
            QMessageBox.critical(self, 'Error', 'Invalid amount format.')
            return

        budgets = self.budget.get(current_date)
        print(budgets)
        for budget in budgets:
            if int(category_id) == int(budget[5]):
                QMessageBox.critical(self, 'Error', f'Budget for {budget[1]} already exists')
                return




        self.budget.add_limit_budget(current_date, category_id, amount)
        self.parent().parent().findChild(BudgetsScreen).update_table()
        self.parent().parent().findChild(BudgetsScreen).update_total_amount()
        self.parent().parent().findChild(BudgetsScreen).update_spent_amount()
        self.parent().parent().findChild(BudgetsScreen).update_remaining_amount()
        time.sleep(0.5)
        self.parent().parent().stackedLayout.setCurrentIndex(2)





