from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel,  QLineEdit, \
    QPushButton, QMessageBox, QComboBox, QDateEdit, QGridLayout
from model import Transaction
from screens.budgets_screen import BudgetsScreen
from model import Category, Type, Budget
from PyQt5.QtCore import QDate, Qt
import time
from PyQt5.QtGui import QIntValidator
from screens.transaction_screen import update_transactions
from screens.budgets_screen import update_budgets

class AddScreen(QWidget):
    """This class provides the methods to creates UI for adding transactions.

    Args:
        QWidget (class): Base class for all user interface elements.
    """

    def __init__(self, account_id):
        super().__init__()

        self.transaction = Transaction(account_id)
        self.budget = Budget(account_id)
        self.type = Type()
        self.category = Category()
        self.init_ui()


    def init_ui(self):
        """This function creates the UI for adding transactions
        """
        self.window_title = QLabel('Add Transactions')
        self.date_edit = QDateEdit()
        self.date_edit.setDisplayFormat("yyyy-MM-dd")
        self.date_edit.setDate(QDate.currentDate())

        self.type_label = QLabel("Income or Expense:")
        self.type_combo = QComboBox()
        self.type_combo.addItem('Select:', userData=0)
        for _type in self.type.get():
            self.type_combo.addItem(_type[1], userData=_type[0])

        self.category_label = QLabel("Category:")
        self.category_combo = QComboBox()
        self.type_combo.currentIndexChanged.connect(self.update_categories)

        self.transaction_name = QLineEdit()

        self.amount_entry = QLineEdit()
        self.amount_entry.setValidator(QIntValidator())

        self.button_layout = QGridLayout()
        self.save_button = QPushButton('Save')
        self.save_button.clicked.connect(self.save_expense)
        self.back_button = QPushButton('Back')
        self.back_button.clicked.connect(self.go_back_home)
        self.button_layout.addWidget(self.save_button, 0, 0)
        self.button_layout.addWidget(self.back_button, 0, 1)
        layout = QVBoxLayout()
        layout.addWidget(self.window_title)
        layout.addWidget(QLabel('Transaction Date:'))
        layout.addWidget(self.date_edit)
        layout.addWidget(self.type_label)
        layout.addWidget(self.type_combo)
        layout.addWidget(self.category_label)
        layout.addWidget(self.category_combo)

        layout.addWidget(QLabel('Transaction Name:'))
        layout.addWidget(self.transaction_name)
        layout.addWidget(QLabel('Amount:'))
        layout.addWidget(self.amount_entry)

        layout.setAlignment(Qt.AlignTop)
        layout.addLayout(self.button_layout)
        self.setLayout(layout)


    def update_categories(self):
        """This function updates the category list based on user's type(Expense or Income) selection
        """
        type_id = self.type_combo.currentData()
        self.category_combo.clear()
        categories = self.category.get(type_id)
        for cat in categories:
            self.category_combo.addItem(cat[1], userData=cat[0])



    def save_expense(self):
        """This function gets the data from add screen UI and saves the data in database. 
           It also updates data in transaction UI and budgets UI.
        """

        category_id = self.category_combo.currentData()
        amount = self.amount_entry.text()
        transaction_name = self.transaction_name.text()
        date = self.date_edit.text()
        type_id = self.type_combo.currentData()
        if not category_id or not amount or not date:
            QMessageBox.critical(self, 'Error', 'Please enter all fields.')
            return
        try:
            amount = float(amount)
        except ValueError:
            QMessageBox.critical(self, 'Error', 'Invalid amount format.')
            return

        self.transaction.add(date, type_id, category_id, amount, transaction_name)    
        self.parent().parent().findChild(BudgetsScreen).set_alert(date, category_id)
        update_transactions(self)
        update_budgets(self)
        time.sleep(0.5)
        self.parent().parent().stackedLayout.setCurrentIndex(0)
        self.category_combo.clear()
        self.amount_entry.clear()
        self.date_edit.setDate(QDate.currentDate())


    def go_back_home(self):
        """This function changes screen to Transaction Screen"""
        self.parent().parent().stackedLayout.setCurrentIndex(0)

