from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel,  QLineEdit, \
    QPushButton, QMessageBox, QComboBox, QDateEdit, QGridLayout

from screens.budgets_screen import BudgetsScreen
from PyQt5.QtCore import QDate, Qt
import time
from screens.transaction_screen import update_transactions
from screens.budgets_screen import update_budgets
from model import Bills
from PyQt5.QtGui import QIntValidator
from screens.bills_screen import update_bills
import datetime

class AddBills(QWidget):
    """This class provides the methods to create UI for adding Bills.

    Args:
        QWidget (class): Base class for all user interface elements.
    """

    def __init__(self, account_id):
        super().__init__()
        self.account_id = account_id
        self.bills = Bills(account_id)
        self.init_ui()


    def init_ui(self):
        """This function creates the UI for adding bills.
        """
        self.window_title = QLabel('Add Bills')

        self.bill_name = QLineEdit()
        self.bill_amount = QLineEdit()
        self.bill_due_day = QLineEdit()
        self.bill_amount.setValidator(QIntValidator())
        self.bill_due_day.setValidator(QIntValidator())


        self.button_layout = QGridLayout()
        self.save_button = QPushButton('Save')
        self.save_button.clicked.connect(self.save_bill)
        self.back_button = QPushButton('Back')
        self.back_button.clicked.connect(self.go_back_bill)
        self.button_layout.addWidget(self.save_button, 0, 0)
        self.button_layout.addWidget(self.back_button, 0, 1)

        layout = QVBoxLayout()
        layout.addWidget(QLabel('Bill Name:'))
        layout.addWidget(self.bill_name)
        layout.addWidget(QLabel('Bill Default Amount:'))
        layout.addWidget(self.bill_amount)
        layout.addWidget(QLabel('Monthly Due Day:'))
        layout.addWidget(self.bill_due_day)
        layout.addLayout(self.button_layout)

        layout.setAlignment(Qt.AlignTop)
        self.setLayout(layout)


    def save_bill(self):
        """This function gets the data from add bill screen UI and saves the data in database. 
           It also updates bills in the main Bills UI.
        """
        bill_name = self.bill_name.text()
        bill_default_amount = self.bill_amount.text()
        bill_due_day = self.bill_due_day.text()

        if not bill_name or not bill_default_amount or not bill_due_day:
            QMessageBox.critical(self, 'Error', 'Please enter all fields.')
            return

        date_obj = datetime.date.today()
        month = date_obj.strftime('%B, %Y')
        existing_bills = self.bills.get(month)
        for bills in existing_bills:
            if bill_name.lower() == bills[1].lower():
                QMessageBox.critical(self, 'Error', f'Bill for {bill_name} already exists.')
                return


        self.bills.add(bill_name, bill_default_amount, bill_due_day)
        update_bills(self)
        self.clear_add_bill_form()
        self.parent().parent().stackedLayout.setCurrentIndex(3)

    def clear_add_bill_form(self):
        self.bill_name.clear()
        self.bill_amount.clear()
        self.bill_due_day.clear()

    def go_back_bill(self):
        """This function changes screen to Bills UI"""
        self.parent().parent().stackedLayout.setCurrentIndex(3)
        self.clear_add_bill_form()



    def update_categories(self):
        type_id = self.type_combo.currentData()
        self.category_combo.clear()
        categories = self.category.get(type_id)
        for cat in categories:
            self.category_combo.addItem(cat[1], userData=cat[0])

