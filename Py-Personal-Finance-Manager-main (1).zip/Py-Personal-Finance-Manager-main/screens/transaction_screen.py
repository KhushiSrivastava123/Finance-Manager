from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, \
    QTableWidgetItem, QPushButton, QHBoxLayout, QLineEdit, QComboBox, \
    QGridLayout
from PyQt5.QtCore import QDate, Qt
from PyQt5.QtGui import QColor, QPalette
from model import DateChange
from model import Transaction
import time
from screens.budgets_screen import update_budgets


def update_transactions(obj):
    """This function updates the Transaction screen's total amount, balance amount and table data.
    """
    obj.parent().parent().findChild(TransactionScreen).update_table()
    obj.parent().parent().findChild(TransactionScreen).update_total_amount()
    obj.parent().parent().findChild(TransactionScreen).update_balance_amount()

class TransactionScreen(QWidget):
    """This class provides the methods to create, modify, update the UI.

    Args:
        QWidget (class): Base class for all user interface elements.
    """

    def __init__(self, account_id):
        super().__init__()
        self.transaction = Transaction(account_id)
        self.date_change = DateChange()
        self.current_date = QDate.currentDate()
        self.date_format = "MMMM d, yyyy"
        self.init_ui()

    def init_ui(self):
        """This function creates the UI for Transactions
        """
        date_layout = QHBoxLayout()
        self.date_edit = QLineEdit(self.current_date.toString(self.date_format))
        self.prev_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.view_type_combo = QComboBox()
        self.view_type_combo.addItems(["Daily", "Monthly", "Yearly"])
        self.prev_button.clicked.connect(self.on_previous_date)
        self.next_button.clicked.connect(self.on_next_date)
        self.view_type_combo.currentIndexChanged.connect(
            self.on_view_type_change)
        date_layout.addWidget(self.prev_button)
        date_layout.addWidget(self.date_edit)
        date_layout.addWidget(self.next_button)
        date_layout.addWidget(self.view_type_combo)

        # Creating total_amount and balance wideget
        total_amt_layout = QHBoxLayout()

        # Total Amount Label
        total_label = QLabel("Total Income:")
        total_label.setAlignment(Qt.AlignLeft)
        total_label.setStyleSheet(
            "background-color: #f0f0f0; color: #333; font-size: 15px; padding: 2px;")

        # Total Amount Value Label
        self.total_value_label = QLabel('')
        self.update_total_amount()
        self.total_value_label.setAlignment(Qt.AlignLeft)
        self.total_value_label.setStyleSheet(
            "background-color: #3daee9; color: #fff; font-size: 16px; padding: 4px;")

        # Balance Amount Label
        self.balance_label = QLabel("Total Expense:")
        self.balance_label.setAlignment(Qt.AlignLeft)
        self.balance_label.setStyleSheet(
            "background-color: #f0f0f0; color: #333; font-size: 15px; padding: 2px;")

        # Balance Amount Value Label
        self.balance_value_label = QLabel('')
        self.update_balance_amount()
        self.balance_value_label.setAlignment(Qt.AlignLeft)
        self.balance_value_label.setStyleSheet(
            "background-color: #3daee9; color: #fff; font-size: 16px; padding: 4px;")

        total_amt_layout.addWidget(total_label)
        total_amt_layout.addWidget(self.total_value_label)

        balance_layout = QHBoxLayout()
        balance_layout.addWidget(self.balance_label)
        balance_layout.addWidget(self.balance_value_label)

        # Set background color
        palette = self.palette()
        palette.setColor(QPalette.Background, QColor(240, 240, 240))
        self.setAutoFillBackground(True)
        self.setPalette(palette)
        label = QLabel('Transactions')
        self.table_widget = QTableWidget()
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(
            4)  # Update to 4 columns for id, category, amount, and date
        self.table_widget.setHorizontalHeaderLabels(
            ["Id", 'Date', "Category", "Amount" ])  # Update header labels

        self.update_table()

        self.add_button_layout = QGridLayout()

        self.addButton = QPushButton("Add", self)
        self.deleteButton = QPushButton("Delete", self)
        self.add_button_layout.addWidget(self.addButton, 0, 0)
        self.add_button_layout.addWidget(self.deleteButton, 0, 1)
        self.addButton.clicked.connect(self.addTransactions)
        self.deleteButton.clicked.connect(self.deleteSelectedRecords)
        layout = QVBoxLayout()
        layout.addLayout(date_layout)
        layout.addLayout(total_amt_layout)
        layout.addLayout(balance_layout)
        layout.addWidget(label)
        layout.addWidget(self.table_widget)
        layout.addLayout(self.add_button_layout)
        self.setLayout(layout)
        self.table_widget.cellClicked.connect(self.editCell)


    def update_table(self):
        """This function updates the transaction table in transaction UI.
        """

        updated_date = self.date_edit.text()
        selected_view = self.view_type_combo.currentText()

        self.table_widget.clearContents()
        transaction = self.transaction.get_data_by_date(
            updated_date,
            selected_view
        )

        self.table_widget.clearContents()
        self.table_widget.setRowCount(len(transaction))
        for row, (tranc_id, category, ammount, datestr) in enumerate(transaction):
            item_id = QTableWidgetItem(str(tranc_id))
            item_category = QTableWidgetItem(category)
            item_amount = QTableWidgetItem(ammount)
            item_date = QTableWidgetItem(datestr)
            item_id.setFlags(item_id.flags() & ~Qt.ItemIsEditable)
            item_category.setFlags(item_category.flags() & ~Qt.ItemIsEditable)
            item_date.setFlags(item_date.flags() & ~Qt.ItemIsEditable)
            self.table_widget.setItem(row, 0, item_id)
            self.table_widget.setItem(row, 2, item_category)
            self.table_widget.setItem(row, 3, item_amount)
            self.table_widget.setItem(row, 1, item_date)
                # Adding colorful background for better visibility

            if row % 2 == 0:
                 # Light Blue
                item_id.setBackground(QColor(191, 235, 255))
                item_category.setBackground(QColor(191, 235, 255))
                item_amount.setBackground(QColor(191, 235, 255))
                item_date.setBackground(QColor(191, 235, 255))

            else:
                 # Powder Blue
                item_id.setBackground(QColor(176, 224, 230))
                item_category.setBackground(QColor(176, 224, 230))
                item_amount.setBackground(QColor(176, 224, 230))
                item_date.setBackground(QColor(176, 224, 230))

    def on_view_type_change(self):
        """This function updates the date bar on user selection based on daily, monthly, yearly
        """
        selected_view = self.view_type_combo.currentText()
        self.date_change.update_date_bar(selected_view)
        self.date_edit.setText(self.date_change.get_current_date().toString(
            self.date_change.get_date_format()))
        self.update_table()

    def on_previous_date(self):
        """This function sets the date based on previous button navigation
        """
        self.date_change.previous_date()
        self.date_edit.setText(self.date_change.get_current_date().toString(
            self.date_change.get_date_format()))
        update_transactions(self)



    def on_next_date(self):
        """This function sets the date based on next button navigation
        """
        self.date_change.next_date()
        self.date_edit.setText(self.date_change.get_current_date().toString(
            self.date_change.get_date_format()))
        update_transactions(self)


    def update_total_amount(self):
        """This function updates total amount lable in transaction UI.
        
        """
        date = self.date_edit.text()
        date_type = self.view_type_combo.currentText()
        amount = self.transaction.get_total_amount(date, date_type)
        self.total_value_label.clear()
        self.total_value_label.setText(f"Rs.{amount}")


    def update_balance_amount(self):
        """This function updates total balance amount lable in transaction UI.
        
        """
        date = self.date_edit.text()
        date_type = self.view_type_combo.currentText()
        amount = self.transaction.get_total_balance(date, date_type)
        self.balance_value_label.clear()
        self.balance_value_label.setText(f"Rs.{amount}")

    def deleteSelectedRecords(self):
        """This function deletes the record from transaction table in transaction UI.
        """
       
        selected_rows = set(
            index.row() for index in self.table_widget.selectedIndexes())
        if not selected_rows:
            return
        selected_rows = sorted(selected_rows, reverse=True)
        for row in selected_rows:
            trans_id = self.table_widget.item(row, 0).text()
            delete_records = self.transaction.delete_transaction(trans_id)
            self.table_widget.removeRow(row)
            update_transactions(self)
            update_budgets(self)


    def addTransactions(self):
        "This function changes the screen to add transaction screen"
        time.sleep(0.5)
        self.parent().parent().stackedLayout.setCurrentIndex(4)

    def editCell(self, row, column):
        """This function edits the record in transaction table in transaction UI.
        """
        if column != 3:
            return
        cell_item = self.table_widget.item(row, column)
        if cell_item:
            cell_text = cell_item.text()
            line_edit = QLineEdit(self)
            line_edit.setText(cell_text)
            line_edit.setAlignment(Qt.AlignCenter)
            line_edit.editingFinished.connect(
                lambda: self.updateCell(row, column, line_edit))
            self.table_widget.removeCellWidget(row, column)
            self.table_widget.setCellWidget(row, column, line_edit)

    def updateCell(self, row, column, line_edit):
        """This function udates the record in transaction table in transaction UI.
        """
       
        new_text = line_edit.text()
        self.table_widget.removeCellWidget(row, column)
        self.table_widget.setItem(row, column, QTableWidgetItem(new_text))
        trans_id = self.table_widget.item(row, 0).text()
        amount = self.table_widget.item(row, 3).text()
        amount = abs(float(amount))
        update_records = self.transaction.update_records(trans_id, amount)
        line_edit.deleteLater()
        self.update_total_amount()
        self.update_balance_amount()








