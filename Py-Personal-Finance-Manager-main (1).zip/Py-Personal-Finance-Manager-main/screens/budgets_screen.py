from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, \
    QPushButton, QTableWidgetItem, QHBoxLayout, QDateEdit, QGridLayout, \
    QLineEdit, QMessageBox
from PyQt5.QtCore import QDate, Qt
import time
from model import Budget
from PyQt5.QtGui import QColor, QPalette



def update_budgets(obj):
    """This function updates the Budget screen's total spent amount, remaining budget and table data.
    """
    obj.parent().parent().findChild(BudgetsScreen).update_spent_amount()
    obj.parent().parent().findChild(BudgetsScreen).update_table()
    obj.parent().parent().findChild(BudgetsScreen).update_spent_amount()
    obj.parent().parent().findChild(BudgetsScreen).update_remaining_amount()

class BudgetsScreen(QWidget):
    """This class provides the methods to create, modify, update the Budget UI.

    Args:
        QWidget (class): Base class for all user interface elements.
    """
    def __init__(self, account_id):
        super().__init__()
        self.current_date = QDate.currentDate()
        self.budget = Budget(account_id)
        self.total_amount = 000
        self.total_spent = 000
        self.remaining_amount = 000
        self.init_ui()

    def init_ui(self):
        """This function creates the UI for Budgets
        """
        label = QLabel('Budgets')
        layout1 = QHBoxLayout()

        # QDateEdit for displaying the current date
        self.date_edit = QDateEdit()
        self.date_edit.setDisplayFormat("MMMM, yyyy")
        self.date_edit.setDate(self.current_date)
        self.date_edit.setReadOnly(True)


        # QPushButton for "Previous" and "Next" functionality
        self.previous_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.previous_button.clicked.connect(self.show_previous_date)
        self.next_button.clicked.connect(self.show_next_date)
        layout1.addWidget(self.previous_button)
        layout1.addWidget(self.date_edit)
        layout1.addWidget(self.next_button)

        self.table_widget = QTableWidget()
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(5)
        self.table_widget.setHorizontalHeaderLabels(
            ["ID", "Category", "Budget Amount", "Spent", "Remaining amount"])

        self.update_table()

        # add_button.clicked.connect(self.add_budget)
        add_button_layout = QGridLayout()
        self.add_button = QPushButton("Add", self)
        self.delete_button = QPushButton("Delete", self)
        self.add_button.clicked.connect(self.AddBudgets)
        self.delete_button.clicked.connect(self.deleteSelectedRecords)
        add_button_layout.addWidget(self.add_button, 0 , 0)
        add_button_layout.addWidget(self.delete_button, 0, 1)

        total_amt_layout = QHBoxLayout()

        # Total Amount Label
        self.total_label = QLabel("Total Budget:")
        self.total_label.setAlignment(Qt.AlignLeft)
        self.total_label.setStyleSheet(
            "background-color: #f0f0f0; color: #333; font-size: 15px; padding: 2px;")

        # Total Amount Value Label
        self.total_value_label = QLabel(f"Rs.{self.total_amount}")
        self.total_value_label.setAlignment(Qt.AlignLeft)
        self.total_value_label.setStyleSheet(
            "background-color: #3daee9; color: #fff; font-size: 16px; padding: 4px;")

        self.total_spent_label = QLabel("Total Spent:")
        self.total_spent_label.setAlignment(Qt.AlignLeft)
        self.total_spent_label.setStyleSheet(
            "background-color: #f0f0f0; color: #333; font-size: 15px; padding: 2px;")

        # Total Spent Amount Value Label
        self.total_spent_value_label = QLabel(f"Rs.{self.total_spent}")
        self.total_spent_value_label.setAlignment(Qt.AlignLeft)
        self.total_spent_value_label.setStyleSheet(
            "background-color: #3daee9; color: #fff; font-size: 16px; padding: 4px;")


        # Balance Spent Amount Label
        self.remaining_amount_label = QLabel("Remaining Amount:")
        self.remaining_amount_label.setAlignment(Qt.AlignLeft)
        self.remaining_amount_label.setStyleSheet(
            "background-color: #f0f0f0; color: #333; font-size: 15px; padding: 2px;")

        # Balance Remaining Amount Value Label
        self.remaining_amount_value_label = QLabel(f"Rs.{self.remaining_amount}")
        self.remaining_amount_value_label.setAlignment(Qt.AlignLeft)
        self.remaining_amount_value_label.setStyleSheet(
            "background-color: #3daee9; color: #fff; font-size: 16px; padding: 4px;")

        total_amt_layout.addWidget(self.total_label)
        total_amt_layout.addWidget(self.total_value_label)

        spent_layout = QHBoxLayout()
        spent_layout.addWidget(self.total_spent_label)
        spent_layout.addWidget(self.total_spent_value_label)

        balance_layout = QHBoxLayout()
        balance_layout.addWidget(self.remaining_amount_label)
        balance_layout.addWidget(self.remaining_amount_value_label)

        # Set background color
        palette = self.palette()
        palette.setColor(QPalette.Background, QColor(240, 240, 240))
        self.setAutoFillBackground(True)
        self.setPalette(palette)

        layout = QVBoxLayout()
        layout.addWidget(label)
        layout.addLayout(layout1)
        layout.addLayout(total_amt_layout)
        layout.addLayout(spent_layout)
        layout.addLayout(balance_layout)
        layout.addWidget(self.table_widget)
        layout.addLayout(add_button_layout)

        self.setLayout(layout)
        self.update_total_amount()
        self.update_spent_amount()
        self.update_remaining_amount()
        self.table_widget.cellClicked.connect(self.editCell)


    def show_previous_date(self):
        """This function sets the date based on previous button navigation
        """
        self.current_date = self.current_date.addMonths(-1)
        self.date_edit.setDate(self.current_date)

        self.update_table()
        self.update_spent_amount()
        self.update_remaining_amount()


    def show_next_date(self):
        """This function sets the date based on next button navigation
        """
        self.current_date = self.current_date.addMonths(1)
        self.date_edit.setDate(self.current_date)
        self.update_table()
        self.update_spent_amount()
        self.update_remaining_amount()


    def AddBudgets(self):
        "This function changes the screen to budget add screen"
        time.sleep(0.5)
        self.parent().parent().stackedLayout.setCurrentIndex(5)


    def update_total_amount(self):
        """This function updates total budget amount lable in budget UI.
        
        """
        self.total_value_label.clear()
        amount = self.budget.total_budget_amount()

        if amount == None:
            self.total_amount = 000
            self.total_value_label.setText(f"Rs.{self.total_amount}")
        else:
            self.total_amount = amount
            self.total_value_label.setText(f"Rs.{self.total_amount}")


    def update_spent_amount(self):
        """This function updates total spent_amount lable in budget UI.
        
        """
        self.total_spent_value_label.clear()
        cur_date = self.date_edit.text()
        amount = self.budget.get_spent_amount(cur_date)
        if amount == None:
            self.total_spent = 000
            self.total_spent_value_label.setText(f"Rs.{self.total_spent}")
        else:
            self.total_spent = amount
            self.total_spent_value_label.setText(f"Rs.{self.total_spent}")


    def update_remaining_amount(self):
        """This function updates remaining_amount lable in budget UI.
        
        """
        self.remaining_amount_value_label.clear()
        cur_date = self.date_edit.text()
        amount = self.budget.get_remaining_amount(cur_date)
        if amount == None:
            self.remaining_amount = 000
            self.remaining_amount_value_label.setText(f"Rs.{self.remaining_amount}")
        else:
            self.remaining_amount = amount
            self.remaining_amount_value_label.setText(f"Rs.{self.remaining_amount}")


    def update_table(self):
        """This function updates the Budget table in Budget UI.
        """
        self.table_widget.clearContents()
        datestr = self.date_edit.text()
        categorized_budgets = self.budget.get(datestr)
        self.table_widget.clearContents()
        self.table_widget.setRowCount(len(categorized_budgets))
        for row, (budget_id, category, ammount_limit, spent_amount, remaining_amount, category_id ) in enumerate(categorized_budgets):
            item_id = QTableWidgetItem(str(budget_id))
            item_category = QTableWidgetItem(category)
            item_amount_limit = QTableWidgetItem(str(ammount_limit))
            item_spent_amount = QTableWidgetItem(str(spent_amount))
            item_remaining_amount = QTableWidgetItem(str(remaining_amount))
            item_id.setFlags(item_id.flags() & ~Qt.ItemIsEditable)
            item_category.setFlags(item_category.flags() & ~Qt.ItemIsEditable)
            item_spent_amount.setFlags(item_spent_amount.flags() & ~Qt.ItemIsEditable)
            item_remaining_amount.setFlags(item_remaining_amount.flags() & ~Qt.ItemIsEditable)
            self.table_widget.setItem(row, 0, item_id)
            self.table_widget.setItem(row, 1, item_category)
            self.table_widget.setItem(row, 2, item_amount_limit)
            self.table_widget.setItem(row, 3, item_spent_amount)
            self.table_widget.setItem(row, 4, item_remaining_amount)

            # Adding colorful background for better visibility
            if row % 2 == 0:
                # Light Blue
                item_id.setBackground(QColor(191, 235, 255))
                item_category.setBackground(QColor(191, 235, 255))
                item_amount_limit.setBackground(QColor(191, 235, 255))
                item_spent_amount.setBackground(QColor(191, 235, 255))
                item_remaining_amount.setBackground(QColor(191, 235, 255))

            else:
                # Powder Blue
                item_id.setBackground(QColor(191, 235, 255))
                item_category.setBackground(QColor(176, 224, 230))
                item_amount_limit.setBackground(QColor(176, 224, 230))
                item_spent_amount.setBackground(QColor(176, 224, 230))
                item_remaining_amount.setBackground(QColor(176, 224, 230))


    def deleteSelectedRecords(self):
        """This function deletes the record from budget table in budget UI.
        """
        selected_rows = set(
            index.row() for index in self.table_widget.selectedIndexes())
        if not selected_rows:
            return
        selected_rows = sorted(selected_rows, reverse=True)
        for row in selected_rows:
            budget_id = self.table_widget.item(row, 0).text()
            self.budget.delete_budget(budget_id)
            self.table_widget.removeRow(row)
            self.update_total_amount()
            self.update_spent_amount()
            self.update_remaining_amount()


    def editCell(self, row, column):
        """This function edits the record in budget table in budget UI.
        """
        if column != 2:
            return
        cell_item = self.table_widget.item(row, column)
        if cell_item:
            cell_text = cell_item.text()
            line_edit = QLineEdit(self)
            line_edit.setText(cell_text)
            line_edit.setAlignment(Qt.AlignCenter)
            line_edit.editingFinished.connect(
                lambda: self.updateCell(row, column, line_edit))
            self.table_widget.removeCellWidget(row, column)
            self.table_widget.setCellWidget(row, column, line_edit)


    def updateCell(self, row, column, line_edit):
        """This function udates the record in budget table in budget UI.
        """
        new_text = line_edit.text()
        self.table_widget.removeCellWidget(row, column)
        new_item = QTableWidgetItem(new_text)
        new_item.setFlags(new_item.flags() & ~Qt.ItemIsEditable)
        self.table_widget.setItem(row, column, QTableWidgetItem(new_item))
        budg_id = self.table_widget.item(row, 0).text()
        budget_amount = self.table_widget.item(row, 2).text()
        self.budget.update_budget(budg_id, budget_amount)
        line_edit.deleteLater()
        self.update_total_amount()
        self.update_spent_amount()
        self.update_remaining_amount()


    def set_alert(self, datestr, category_id):
        """This function alerts the user the the budget exceeds.

        Args:
            datestr (str): date
            category_id (int): Category_id
        """

        exceeded_categories = self.budget.get_exceeded_budget(datestr, category_id)

        if exceeded_categories:
            x = exceeded_categories[0]
            msg = f'Budget {x[0]}  has exceeded by Rs. {x[3]}'
            popup = QMessageBox()
            popup.setWindowTitle("Budget Exceeded")
            popup.setText(msg)
            popup.setIcon(QMessageBox.Warning)
            popup.setStandardButtons(QMessageBox.Ok)
            popup.exec_()
        else:
            print("No categories have exceeded the budget.")
