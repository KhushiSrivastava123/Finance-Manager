from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QDateEdit, \
    QPushButton
from PyQt5.QtCore import QDate
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from model import Statistics
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from datetime import date
from PyQt5.QtCore import Qt
import numpy as np
from model import Budget
import datetime


class StatsScreen(QWidget):
    """This class provides the methods to create, modify, update the Graph UI.

        Args:
            QWidget (class): Base class for all user interface elements.
    """
    def __init__(self, account_id):
        super().__init__()
        self.current_date = QDate.currentDate()
        self.stats = Statistics(account_id)
        self.budget = Budget(account_id)

        self.init_ui()

    def init_ui(self):
        """This function creates the Graph UI
        """
        # label = QLabel('Analysis')
        date_layout = QHBoxLayout()
        # QDateEdit for displaying the current date
        self.date_edit = QDateEdit()
        self.date_edit.setDisplayFormat("MMMM, yyyy")
        self.date_edit.setDate(self.current_date)
        self.date_edit.setReadOnly(True)
        self.previous_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.previous_button.clicked.connect(self.show_previous_date)
        self.next_button.clicked.connect(self.show_next_date)
        date_layout.addWidget(self.previous_button)
        date_layout.addWidget(self.date_edit)
        date_layout.addWidget(self.next_button)

        # self.fig1, self.ax1 = plt.subplots(figsize=(15, 15), layout='constrained')
        # self.fig2, self.ax2 = plt.subplots(figsize=(15, 15), layout='constrained')
        # self.fig3, self.ax3 = plt.subplots(figsize=(15, 15), layout='constrained')
        # self.fig4, self.ax4 = plt.subplots(figsize=(15, 15), layout='constrained')

        self.fig1 = Figure()
        self.fig2 = Figure()
        self.fig3 = Figure()
        self.fig4 = Figure()

        self.canvas1 = FigureCanvas(self.fig1)
        self.canvas2 = FigureCanvas(self.fig2)
        self.canvas3 = FigureCanvas(self.fig3)
        self.canvas4 = FigureCanvas(self.fig4)

        self.horizontal_plot_layout1 = QHBoxLayout()
        self.horizontal_plot_layout1.addWidget(self.canvas1)
        self.horizontal_plot_layout1.addWidget(self.canvas2)

        self.horizontal_plot_layout2 = QHBoxLayout()
        self.horizontal_plot_layout2.addWidget(self.canvas3)
        self.horizontal_plot_layout2.addWidget(self.canvas4)

        layout = QVBoxLayout(self)
        layout.addLayout(date_layout)
        layout.setAlignment(Qt.AlignTop)
        layout.addLayout(self.horizontal_plot_layout1)
        layout.addLayout(self.horizontal_plot_layout2)
        self.update_charts()
        self.setLayout(layout)





    def update_charts(self):
        cur_date = self.date_edit.text()
        date_obj = datetime.datetime.strptime(cur_date, '%B, %Y').date()
        cat_data = self.stats.get_monthly_expense_data(cur_date)
        categories = [item[0] for item in cat_data]
        amounts = [item[1] for item in cat_data]

        self.fig1.clear()
        self.fig2.clear()
        self.fig3.clear()
        self.fig4.clear()

        ax1 = self.fig1.add_subplot(111)
        ax2 = self.fig2.add_subplot(111)
        ax3 = self.fig3.add_subplot(111)
        ax4 = self.fig4.add_subplot(111)


        ax1.bar(categories, amounts)
        ax1.set_title('Expense Analysis')
        ax1.set_xlabel('Categories')
        data = self.stats.get_month_analysis(date_obj)
        income = [item[0] for item in data]
        expense = [item[1] for item in data]
        saving = [item[2] for item in data]
        month = [item[3] for item in data]

        ax2.plot(month, income, label='Income')
        ax2.plot(month, expense, label='Expense')
        ax2.set_xlabel('Months')
        ax2.set_ylabel('Amount')
        ax2.set_ylim(ymin=0)
        ax2.set_title("Income and Expense Trends")
        ax2.legend()

        date = self.date_edit.text()
        data = self.budget.get(date)
        category = [item[1] for item in data]
        budget = [float(item[2]) for item in data]
        angle = -180 * budget[0]
        wedges, *_ = ax3.pie(budget, autopct='%1.1f%%',
                             startangle=angle,
                             labels=category)
        ax3.set_title("Budget by Category")

        ax4.plot(month, saving, label='Savings')
        ax4.set_xlabel('Months')
        ax4.set_ylabel('Amount')
        ax4.set_ylim(ymin=0)
        ax4.set_title("Savings Trends")
        ax4.legend()
        self.canvas1.draw()
        self.canvas2.draw()
        self.canvas3.draw()
        self.canvas4.draw()






        # return
        # date = self.date_edit.text()
        # data = self.stats.get_monthly_expense_data(date)
        # labels = [item[0] for item in data]
        # amounts = [float(item[1]) for item in data]
        # total_amount = sum(amounts)
        #
        # # Clear any existing plots and create a new one
        # self.figure1.clear()
        # ax = self.figure1.add_subplot(211)
        #
        # # Plot a bar chart
        # # bars = ax.bar(labels, amounts)
        # # for bar, amount in zip(bars, amounts):
        # #     percentage = (amount / total_amount) * 100
        # #     ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
        # #             f'{percentage:.1f}%', ha='center')
        #
        # # Customize the plot if needed (e.g., set labels and title)
        # ax.set_xlabel('Categories')
        # ax.set_ylabel('Amount')
        # ax.set_title('Expense Distribution')
        # self.canvas1.draw()
        #
        # # Draw the plot on the canvas
        # # self.canvas1.draw()
    def show_previous_date(self):
        self.current_date = self.current_date.addMonths(-1)
        self.date_edit.setDate(self.current_date)
        self.update_charts()


    def show_next_date(self):
        self.current_date = self.current_date.addMonths(1)
        self.date_edit.setDate(self.current_date)
        self.update_charts()
