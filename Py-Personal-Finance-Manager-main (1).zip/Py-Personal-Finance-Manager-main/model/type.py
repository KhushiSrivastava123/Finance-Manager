from .abs_model import AbstractModel


class Type(AbstractModel):
    """This class provides the method to get the type like Income and Expense.

    Args:
        AbstractModel (class): Class for database connection
    """

    def get(self):
        """This function gets the type from type table.

        Returns:
            res (tuple(tuple)): Type Id and Types
        """
        query = 'SELECT TYPE_ID, NAME FROM TYPE'
        self.cur.execute(query)
        res = self.cur.fetchall()
        return res




