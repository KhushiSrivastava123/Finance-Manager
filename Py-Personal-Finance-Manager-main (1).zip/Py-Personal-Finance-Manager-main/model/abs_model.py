import pymysql
import yaml

class AbstractModel:
    """ This class provides configuration required to set up the Mysql connection using Pymysql 
    """

    def __init__(self, user_id=None):
        config_file = 'config.local.yaml'
        with open(config_file, 'r') as file:
            self.config = yaml.safe_load(file)

        self.connection = pymysql.connect(
            host=self.config['hostname'],
            port=self.config['port'],
            user=self.config['username'],
            password=self.config['password'],
            db=self.config['database_name'],
            autocommit=True

        )
        self.cur = self.connection.cursor()
        if user_id:
            self.user_id = user_id