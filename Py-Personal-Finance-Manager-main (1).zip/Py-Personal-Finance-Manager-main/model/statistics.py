from .abs_model import AbstractModel


class Statistics(AbstractModel):


    def get_monthly_expense_data(self, date):
        query = (
            "SELECT CAT.NAME, SUM(TR.AMOUNT) FROM TRANSACTIONS AS TR "
            "JOIN CATEGORIES AS CAT ON CAT.CATEGORY_ID = TR.CATEGORY_ID "
            "WHERE TR.TYPE_ID=2 AND DATE_FORMAT(TRANSACTION_DATE, %s) = %s "
            "GROUP BY TR.CATEGORY_ID"
        )
        date_format = '%M, %Y'
        values = (date_format, date)
        self.cur.execute(query, values)
        res = self.cur.fetchall()
        return res

    def get_month_analysis(self, date):
        query = '''
        WITH EXPENSE_TABLE AS (
            SELECT SUM(AMOUNT) AS EXPENSE, MONTHNAME(TRANSACTION_DATE) AS MONTH
            FROM TRANSACTIONS WHERE TYPE_ID = 2 AND TRANSACTION_DATE >= DATE_SUB(%s, INTERVAL 6 MONTH) AND
            TRANSACTION_DATE <= DATE_ADD(%s, INTERVAL 1 MONTH) AND ACCOUNT_ID = %s
            GROUP BY MONTH(TRANSACTION_DATE)
        ),
        INCOME_TABLE AS (
            SELECT SUM(AMOUNT) AS INCOME, MONTHNAME(TRANSACTION_DATE) AS MONTH
            FROM TRANSACTIONS WHERE TYPE_ID = 1 AND TRANSACTION_DATE >= DATE_SUB(%s, INTERVAL 6 MONTH) AND
            TRANSACTION_DATE <= DATE_ADD(%s, INTERVAL 1 MONTH) AND ACCOUNT_ID = %s
            GROUP BY MONTH(TRANSACTION_DATE)
        ),
        DATA AS (
            SELECT IFNULL(INCOME, 0) AS INCOME, IFNULL(EXPENSE,0) AS EXPENSE, E.MONTH
            FROM EXPENSE_TABLE AS E
            LEFT JOIN
            INCOME_TABLE AS I ON E.MONTH = I.MONTH
            UNION
            SELECT IFNULL(INCOME, 0) AS INCOME, IFNULL(EXPENSE,0) AS EXPENSE, E.MONTH
            FROM EXPENSE_TABLE AS E
            RIGHT JOIN
            INCOME_TABLE AS I ON E.MONTH = I.MONTH
        )
        SELECT INCOME, EXPENSE, (INCOME - EXPENSE) AS SAVINGS, MONTH FROM DATA;
        '''
        self.cur.execute(query, (date, date, self.user_id, date, date, self.user_id))
        res = self.cur.fetchall()
        return res


