from PyQt5.QtCore import QDate

class DateChange:

    """
    This class represents the methods required for changing dates based on daily,
    monthly, yearly selection by users
    """

    def __init__(self):
        self.current_date = QDate.currentDate()
        self.date_format = "MMMM d, yyyy"

    def get_current_date(self):
        """This function gets the current date
        """
        return self.current_date


    def get_date_format(self):
        """This function gets the date format
        """
        return self.date_format


    def update_date_bar(self, selected_view):
        """This function sets the date format based on daily, monthly, yearly selection
        """
        if selected_view == "Daily":
            self.date_format = "MMMM d, yyyy"
        elif selected_view == "Monthly":
            self.date_format = "MMMM, yyyy"
        elif selected_view == "Yearly":
            self.date_format = "yyyy"


    def previous_date(self):
        """This function decrease the date based on previous button navigation
        """
        if self.date_format == "yyyy":
            self.current_date = self.current_date.addYears(-1)
        elif self.date_format == "MMMM, yyyy":
            self.current_date = self.current_date.addMonths(-1)
        else:
            self.current_date = self.current_date.addDays(-1)


    def next_date(self):
        """This function increases the date based on next button navigation
        """
        if self.date_format == "yyyy":
            self.current_date = self.current_date.addYears(1)
        elif self.date_format == "MMMM, yyyy":
            self.current_date = self.current_date.addMonths(1)
        else:
            self.current_date = self.current_date.addDays(1)

