from model.abs_model import AbstractModel
import datetime

class Bills(AbstractModel):
    """This class provides the methods for users to  add, pay and get information about the bills
    """

    def add(self, bill_name, bill_default_amount, bill_due_day):
        """This function will add a bill into the bills table.

        Args:
            bill_name (str): bill name
            bill_default_amount (float): default bill amount 
            bill_due_day (int): bill payment due day 
        """
        query = (
            "INSERT INTO BILLS ("
            "NAME, BILL_DUE_DAY, DEFAULT_AMOUNT, CREATED_DT, ACCOUNT_ID) "
            "VALUES (%s, %s, %s, %s, %s)"
        )
        date = datetime.date.today()
        self.cur.execute(query, (bill_name, bill_due_day, bill_default_amount, date, self.user_id))


    def get(self, month):
        """This function retrieves the bill information from the table based on month.

        Args:
            month (str): Month name

        Returns:
            res (tuple(tuple)): Bills information based on the selection of month
        """

        query = '''
            WITH FILTERED_TRANSACTION AS (
                SELECT * FROM TRANSACTIONS 
                WHERE DATE_FORMAT(TRANSACTION_DATE, %s) = %s AND ACCOUNT_ID = %s
            )
            SELECT BILL_ID, B.NAME, 
            IF(T.AMOUNT IS NULL, DEFAULT_AMOUNT, AMOUNT) AS AMOUNT, 
            IF(T.AMOUNT IS NULL, FALSE, TRUE) AS PAID
            FROM BILLS AS B 
            LEFT JOIN FILTERED_TRANSACTION AS T 
            ON LOWER(B.NAME) = LOWER(T.NAME) WHERE B.ACCOUNT_ID = %s;
            '''
        self.cur.execute(query, ('%M, %Y', month, self.user_id, self.user_id))
        res = self.cur.fetchall()
        return res


    def pay(self, bill_id, name, amount, month):
        """This function adds the bill to transaction table when the user pays the bill.

        Args:
            name (str): Bill name
            amount (str): _Bill amount
            month (str): Month number
        """
        query = (
            'INSERT INTO TRANSACTIONS ('
            'AMOUNT, NAME, TRANSACTION_DATE, '
            'ACCOUNT_ID, CATEGORY_ID, TYPE_ID) '
            'VALUES (%s, %s, %s, %s, %s, %s)'
        )
        date = datetime.datetime.strptime(month, '%B, %Y').date()
        self.cur.execute(query, (amount, name, date, self.user_id, 2, 2))


    def delete(self, bill_id):
        """_This function deletes the bill record based on bill id

        Args:
            bill_id (str): Bill id 
        """
        query = (
            'DELETE FROM BILLS WHERE BILL_ID = %s'
        )
        self.cur.execute(query, bill_id)
