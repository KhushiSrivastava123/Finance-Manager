from decimal import Decimal
from .abs_model import AbstractModel


class Transaction(AbstractModel):
    """This class provides the methods for user transactions.

    Args:
        AbstractModel (Class): Class for database connection
    """

    def __init__(self, user_id):
        super().__init__(user_id)
        self.date_format = {
            "Yearly": '%Y',
            "Monthly": '%M, %Y',
            "Daily": '%M %e, %Y',
        }

    def get(self):
        """This function gets the transaction details from the table.

        Returns:
            transaction (tuple(tuple)): Category names and transaction amount
        """
        query = (
            "SELECT CAT.NAME, TR.AMOUNT "
            "FROM TRANSACTIONS AS TR " 
            "JOIN CATEGORIES AS CAT ON CAT.CATEGORY_ID = TR.CATEGORY_ID " 
            "JOIN ACCOUNTS AS AC ON AC.ACCOUNT_ID = TR.ACCOUNT_ID " 
            "WHERE TR.ACCOUNT_ID = %s"
        )
        val = self.user_id
        self.cur.execute(query, val)
        transactions = self.cur.fetchall()
        return transactions
    

    def add(self, date, type_id, category_id, amount, transaction_name):
        """This function adds the transactions into table.

        Args:
            date (str): Date
            type_id (int): Type Id_
            category_id (int): Category Id
            amount (str): Amount_
            transaction_name (str): Note for transaction
        """

        amount = Decimal(amount)
        query = (
            "INSERT INTO TRANSACTIONS (AMOUNT, TRANSACTION_DATE, ACCOUNT_ID, " 
            "CATEGORY_ID, TYPE_ID, NAME) VALUES (%s, %s , %s , %s ,%s, %s)"
        )
        values = (amount, date, self.user_id, category_id, type_id, transaction_name)
        self.cur.execute(query, values)


    def delete_transaction(self, trans_id):
        """This funciton deletes the transactions from the transaction table for the given transaction_id.

        Args:
            trans_id (str): Transaction Id
        """
        
        transaction_id = int(trans_id)
        query = (
            "DELETE FROM TRANSACTIONS WHERE TRANSACTION_ID = %s"
        )
        self.cur.execute(query, transaction_id)
        self.cur.fetchall()


    def update_records(self, trans_id, amount):
        """This function will update the transaction in the budget table for the given transaction_id

        Args:
            trans_id (str): Transaction Id
            amount (str): Transaction Amount
        """

        transaction_id = int(trans_id)
        query = (
            "UPDATE TRANSACTIONS SET AMOUNT = %s WHERE TRANSACTION_ID = %s"
        )
        values = (amount, transaction_id)
        self.cur.execute(query, values)


    def get_data_by_date(self, date, selected_view):
        """This funnction retrieves transaction information based on the date and selected view.

        Args:
            date (str): Date
            selected_view (str): Daily, Monthly, weekly

        Returns:
            transactions tuple(tuple): Transactions
        """
        query = (
            "SELECT TR.TRANSACTION_ID, CAT.NAME, "
            "CONCAT(IF(TR.TYPE_ID = 1, '+', '-'), CONVERT(AMOUNT, CHAR)) AS AMOUNT, "
            "CONVERT(TR.TRANSACTION_DATE, CHAR) "
            "FROM TRANSACTIONS as TR "
            "JOIN CATEGORIES AS CAT ON CAT.CATEGORY_ID = TR.CATEGORY_ID "
            "JOIN ACCOUNTS AS ACC ON ACC.ACCOUNT_ID = TR.ACCOUNT_ID "
            "WHERE TR.ACCOUNT_ID = %s AND DATE_FORMAT(TRANSACTION_DATE, %s) = %s"
        )

        values = (self.user_id, self.date_format[selected_view], date)
        self.cur.execute(query, values)
        transactions = self.cur.fetchall()
        return transactions
    

    def get_total_amount(self, datestr, view_type):
        """This function gets the total transaction amount associated with income categories.

        Returns:
            amount (Decimal): Sum of total amount amount
        """

        query = (
            "SELECT IFNULL(SUM(AMOUNT), 0) AS AMOUNT "
            "FROM TRANSACTIONS WHERE ACCOUNT_ID = %s AND TYPE_ID = 1 "
            "AND DATE_FORMAT(TRANSACTION_DATE, %s) = %s"
        )
        self.cur.execute(query, (self.user_id, self.date_format[view_type], datestr))
        res = self.cur.fetchone()
        return res[0]


    def get_total_balance(self, datestr, view_type):
        """This function returns the total balance amount from the transaction table for the given date ans view type.

        Args:
            date (str): Date
            view_type (str): Daily, Monthly, yearly

        Returns:
            res (Decimal): Sum of transaction amount 
        """
        
        query = (
            "SELECT( "
            "SELECT IFNULL(SUM(AMOUNT), 0) "
            "FROM TRANSACTIONS WHERE ACCOUNT_ID = %s AND TYPE_ID = 1 "
            "AND DATE_FORMAT(TRANSACTION_DATE, %s) = %s) " 
            "- ("
            "SELECT IFNULL(SUM(AMOUNT), 0) "
            "FROM TRANSACTIONS WHERE ACCOUNT_ID = %s AND TYPE_ID = 2 "
            "AND DATE_FORMAT(TRANSACTION_DATE, %s) = %s"
            ") AS result"
        )
        val = (
            self.user_id, self.date_format[view_type], datestr,
            self.user_id, self.date_format[view_type], datestr
        )
        self.cur.execute(query, val)
        res = self.cur.fetchone()
        return res[0]



