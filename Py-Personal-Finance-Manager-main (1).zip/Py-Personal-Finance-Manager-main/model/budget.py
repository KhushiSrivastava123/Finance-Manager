from .abs_model import AbstractModel
from decimal import Decimal

class Budget(AbstractModel):
    """ This class provides the methods for user to add, get, update and delete  the budgets.
    """

    def add_limit_budget(self, date, category_id, amount_limit):
        """ This function adds budget information into table

        Args:
            date (date): Current Date
            category_id (int): Category Id
            amount_limit (str): Budget Limit
        """
        query = (
            "INSERT INTO BUDGETS (AMOUNT_LIMIT, CREATED_DT, ACCOUNT_ID, CATEGORY_ID) "
            "VALUES (%s, %s, %s, %s)"
        )
        values = (amount_limit, date, self.user_id, category_id)
        self.cur.execute(query, values)

    def get(self, datestr):
        """This funnction retrieves budget information based on the date.
        Args:
            date (str): Current Date

        """
        query = (
            """
            with FILTERED_TRANSACTIONS as (
            SELECT * FROM TRANSACTIONS
            WHERE DATE_FORMAT(TRANSACTION_DATE, %s) = %s AND ACCOUNT_ID = %s
            )
            SELECT BG.BUDGET_ID, CT.NAME, BG.AMOUNT_LIMIT, IFNULL(SUM(TR.AMOUNT), 0) AS
            EXPENSE_AMOUNT, (BG.AMOUNT_LIMIT - IFNULL(SUM(TR.AMOUNT), 0)) AS REMAINING_BUDGET,
            CT.CATEGORY_ID
            FROM BUDGETS AS BG
            LEFT JOIN FILTERED_TRANSACTIONS AS TR ON BG.CATEGORY_ID = TR.CATEGORY_ID
            JOIN CATEGORIES AS CT ON BG.CATEGORY_ID=CT.CATEGORY_ID WHERE BG.ACCOUNT_ID = %s
            GROUP BY BG.BUDGET_ID;
            """
        )
        self.cur.execute(query, ('%M, %Y', datestr, self.user_id, self.user_id))
        categorized_budgets = self.cur.fetchall()
        return categorized_budgets

    def total_budget_amount(self):
        """This function gets the total budget amount associated with expense categories.

        Returns:
            amount (Decimal): Sum of Budget amount
        """
        query = (
            "SELECT IFNULL(SUM(AMOUNT_LIMIT), 0) FROM BUDGETS WHERE ACCOUNT_ID = %s"
        )
        self.cur.execute(query, self.user_id)
        amount = self.cur.fetchone()
        return amount[0]

    def get_spent_amount(self, date):
        """This function returns the total spent amount from the budget table for the given date.

        Args:
            date (str): Month and the year

        Returns:
            res (Decimal): Sum of transaction amount 
        """

        query = (
            "SELECT IFNULL(SUM(TR.AMOUNT), 0) AS  EXPENSE_AMOUNT FROM BUDGETS AS BG "
            "JOIN TRANSACTIONS AS TR ON BG.CATEGORY_ID = TR.CATEGORY_ID  AND BG.ACCOUNT_ID = TR.ACCOUNT_ID "
            "JOIN CATEGORIES AS CT ON BG.CATEGORY_ID=CT.CATEGORY_ID WHERE DATE_FORMAT(TRANSACTION_DATE, %s) = %s AND BG.ACCOUNT_ID = %s"
        )
        self.cur.execute(query, ('%M, %Y', date, self.user_id))
        res = self.cur.fetchone()
        return res[0]


    def get_remaining_amount(self, date):
        """This function will fetch total remaining budget for the given date.

        Args:
            date (str): Month and the year
        """
        print(date, self.user_id)
        query = (
            "SELECT (SELECT IFNULL(SUM(AMOUNT_LIMIT), 0) AS BUDGET_AMOUNT FROM BUDGETS WHERE ACCOUNT_ID = %s) "
            " - (SELECT IFNULL(SUM(TR.AMOUNT), 0) AS REMAINING_AMOUNT FROM TRANSACTIONS AS TR "
            "JOIN BUDGETS AS BG ON BG.CATEGORY_ID = TR.CATEGORY_ID "
            "WHERE DATE_FORMAT(TRANSACTION_DATE, %s) = %s AND BG.ACCOUNT_ID = %s)"

        )
        self.cur.execute(query, (self.user_id, '%M, %Y', date, self.user_id))
        remaining_amount = self.cur.fetchone()
        print(remaining_amount)
        return remaining_amount[0]
    

    def delete_budget(self, budgt_id):
        """This funciton deletes buget from the budget table for the given budget_id.

        Args:
            budgt_id (str): Budget Id
        """

        budget_id = int(budgt_id)
        query = (
            "DELETE FROM BUDGETS WHERE BUDGET_ID = %s"
        )
        self.cur.execute(query, budget_id)
        self.cur.fetchall()


    def update_budget(self, budgt_id, amount):
        """This function will update the budget in the budget table for the given budget_id.

        Args:
            budgt_id (str): Budget Id
            amount (str): Budget Amount
        """
        budget_id = int(budgt_id)
        query = (
            "UPDATE BUDGETS SET AMOUNT_LIMIT = %s WHERE BUDGET_ID = %s"
        )
        values = (amount, budget_id)
        self.cur.execute(query, values)


    def get_exceeded_budget(self, datestr, category_id):
        """
        This function will return the categories with budget limits that have been exceeded.

        Args:
            date (str): Date
            category_id (int): Category Id

        """
        
        query = """
            WITH EXPENSE AS (
                SELECT SUM(AMOUNT) AS TOTAL_EXPENSE, CATEGORY_ID
                FROM TRANSACTIONS AS T
                WHERE TYPE_ID = 2 AND DATE_FORMAT(TRANSACTION_DATE, %s) = DATE_FORMAT(CURRENT_DATE(), %s)
                AND CATEGORY_ID = %s AND ACCOUNT_ID = %s GROUP BY CATEGORY_ID
            )
            SELECT C.NAME, B.AMOUNT_LIMIT, E.TOTAL_EXPENSE, (B.AMOUNT_LIMIT - E.TOTAL_EXPENSE )
            FROM BUDGETS AS B
            INNER JOIN EXPENSE AS E ON B.CATEGORY_ID = E.CATEGORY_ID
            INNER JOIN CATEGORIES AS C ON B.CATEGORY_ID = C.CATEGORY_ID
            WHERE AMOUNT_LIMIT < TOTAL_EXPENSE AND B.ACCOUNT_ID = %s;
        """
        val = ('%M, %Y', '%M, %Y', category_id, self.user_id, self.user_id)
        self.cur.execute(query, val)
        res = self.cur.fetchall()
        return res


