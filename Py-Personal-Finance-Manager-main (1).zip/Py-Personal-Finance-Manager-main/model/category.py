from .abs_model import AbstractModel


class Category(AbstractModel):
    """This class provides the methods to extract category names.
    """


    def get(self, type_id):
        """This function gets the category based on type(expenses or income).

        Args:
            type_id (int): Type Id_

        Returns:
            res (tuple(tuple)): ((1, Bills))
        """
        self.cur.execute(
            'SELECT CATEGORY_ID, NAME FROM CATEGORIES WHERE TYPE_ID = %s', type_id
        )
        res = self.cur.fetchall()
        return res


    def get_budget_category(self):
        """This function will query the categories for Expense category
        """
        
        self.cur.execute(
            'SELECT NAME FROM CATEGORIES WHERE TYPE_ID = 2',
        )
        res = self.cur.fetchall()
        return res



    



