import pymysql
import bcrypt
from model.abs_model import AbstractModel

class Account(AbstractModel):
    """This class provides the functions to add and authenticate
    the users credentials.
    """
    

    def encrypt_passwd(self, passwd):
        """This function encrypts the user password.

        Args:
            passwd (str): password

        Returns:
           hashed_paswd (str) : Hashed password
        """

        bytes = passwd.encode('utf-8')
        salt = bcrypt.gensalt()
        hashed_paswd = bcrypt.hashpw(bytes, salt)
        return hashed_paswd
    

    def check_email(self, mail_address):
        """This function will check if email_address exists in the table. 

        Args:
            mail_address (str): Email_addresss

        Returns:
            row(tuple(tuple(str))): Email_address
        """

        check_query = "select EMAIL from ACCOUNTS where EMAIL = %s"
        self.cur.execute(check_query, mail_address)
        row = self.cur.fetchone()
        return row


    def check_password(self, passwd):
        """This function checks the user's password.

        Args:
            passwd (str): Password

        Returns:
            _Bool: True or False
        """
        if len(passwd) > 6:
            return True
        else:
            return False


    def add_credentials(self, mail_address, encrypted_pswd):
        """This function will add user's credentials into table.

        Args:
            mail_address (str): Email_addresss
            encrypted_pswd (str): Encrypted password
        """
        sql_query = "INSERT INTO ACCOUNTS (EMAIL, PASSWORD) VALUES (%s, %s)"
        self.cur.execute(sql_query, (mail_address, encrypted_pswd))


    def check_authentication(self, email_address, passwd):
        """This function verifies user authentication using their credentials.

        Args:
            email_address (str): Email_addresss
            passwd (str): Password

        Returns:
            Bool: True or False
        """
        sql_query = "SELECT PASSWORD FROM ACCOUNTS WHERE EMAIL = %s"
        self.cur.execute(sql_query, (email_address,))
        hashed_password = self.cur.fetchone()

        if hashed_password != None:
            hash_pswd_res = hashed_password[0]
            user_pswd = passwd.encode('utf-8')
            byte_string_hash = hash_pswd_res.encode('ascii')
            if bcrypt.checkpw(user_pswd, byte_string_hash):
                return True
        else:
            return False



